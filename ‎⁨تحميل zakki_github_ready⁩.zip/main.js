// فتح وإغلاق القائمة الجانبية
        const menuToggle = document.getElementById('menuToggle');
        const drawer = document.getElementById('drawer');
        const overlay = document.getElementById('overlay');
        
        menuToggle.addEventListener('click', () => {
            drawer.classList.toggle('open');
            overlay.classList.toggle('active');
        });
        
        overlay.addEventListener('click', () => {
            drawer.classList.remove('open');
            overlay.classList.remove('active');
        });
        
        // التبديل بين الوضع الليلي والنهاري
        const darkModeToggle = document.getElementById('darkModeToggle');
        const body = document.body;
        
        darkModeToggle.addEventListener('click', () => {
            body.classList.toggle('dark-mode');
            
            // تغيير الأيقونة
            const icon = darkModeToggle.querySelector('i');
            if (body.classList.contains('dark-mode')) {
                icon.classList.remove('fa-moon');
                icon.classList.add('fa-sun');
            } else {
                icon.classList.remove('fa-sun');
                icon.classList.add('fa-moon');
            }
        });
        
        // إنشاء لوحة الصدارة
        const leaderboardContent = document.getElementById('leaderboard-content');
        const traders = [
            { name: 'علي حسن', city: 'بغداد', points: 3200 },
            { name: 'سهاد محمد', city: 'البصرة', points: 2850 },
            { name: 'حسن كريم', city: 'أربيل', points: 2650 },
            { name: 'زهراء عبدالله', city: 'الناصرية', points: 2400 },
            { name: 'مصطفى أحمد', city: 'كركوك', points: 2150 }
        ];
        
        traders.forEach((trader, index) => {
            const traderEl = document.createElement('div');
            traderEl.style.padding = '10px 0';
            traderEl.style.borderBottom = '1px solid rgba(0,0,0,0.1)';
            traderEl.style.display = 'flex';
            traderEl.style.justifyContent = 'space-between';
            traderEl.style.alignItems = 'center';
            
            traderEl.innerHTML = `
                <div style="display: flex; align-items: center; gap: 10px;">
                    <div style="width: 30px; height: 30px; border-radius: 50%; background: ${index < 3 ? '#FF6B00' : '#8A8A8A'}; color: white; display: flex; align-items: center; justify-content: center; font-weight: bold;">
                        ${index + 1}
                    </div>
                    <div>
                        <div style="font-weight: bold;">${trader.name}</div>
                        <div style="font-size: 12px; color: #8A8A8A;">${trader.city}</div>
                    </div>
                </div>
                <div style="font-weight: bold; color: #FF6B00;">${trader.points} نقطة</div>
            `;
            
            leaderboardContent.appendChild(traderEl);
        });
        
        // تفعيل فلتر المنتجات
        const filterBtns = document.querySelectorAll('.filter-btn');
        filterBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                filterBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
            });
        });
        
        // تفعيل خيارات اختبار التاجر
        const options = document.querySelectorAll('.option');
        options.forEach(option => {
            option.addEventListener('click', () => {
                options.forEach(opt => opt.style.backgroundColor = '');
                option.style.backgroundColor = 'var(--primary-light)';
                
                // الانتقال للسؤال التالي بعد تأخير
                setTimeout(() => {
                    document.querySelector('.test-progress-fill').style.width = '66%';
                    document.querySelector('.test-question').textContent = 'كم ساعة باليوم تقدر تخصصها لمشروعك؟';
                    options.forEach((opt, i) => {
                        opt.textContent = [
                            'ساعة أو أقل',
                            '2-3 ساعات',
                            '4-6 ساعات',
                            'أكثر من 6 ساعات'
                        ][i];
                    });
                }, 800);
            });
        });
        
        // تفاعل مساعد الذكاء الاصطناعي
        const aiAssistant = document.querySelector('.ai-assistant');
        aiAssistant.addEventListener('click', () => {
            alert('مرحباً! أنا مساعد Zakki الذكي. كيف يمكنني مساعدتك اليوم؟');
        });
        
        // تأثير التمرير السلس
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
        
        // تحريك شريط التقدم
        setTimeout(() => {
            document.querySelector('.progress-fill').style.width = '65%';
        }, 500);